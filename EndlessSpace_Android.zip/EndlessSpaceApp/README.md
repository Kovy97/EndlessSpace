# Endless Space als Android-App

Dieses Projekt verpackt `EndlessSpace.html` in eine eigenständige Android-App (APK).
Die App läuft komplett offline, braucht keine Berechtigungen und funktioniert ab Android 7.0.

## Weg A: APK von GitHub bauen lassen (ohne Installation am PC)

1. Auf [github.com](https://github.com) ein kostenloses Konto anlegen bzw. anmelden.
2. Oben rechts **+ → New repository**. Name zum Beispiel `endless-space-app`, **Private** auswählen, **Create repository**.
3. Auf der leeren Repository-Seite auf **uploading an existing file** klicken.
4. Diese ZIP entpacken und den **Inhalt** des Ordners `EndlessSpaceApp` (nicht den Ordner selbst) ins Browserfenster ziehen, dann **Commit changes**.
   - Der Ordner `.github` muss mit hochgeladen werden. Auf dem Mac ist er versteckt: im Finder `Cmd + Shift + .` drücken.
   - Falls er trotzdem fehlt: Reiter **Actions → set up a workflow yourself**, den Inhalt von `.github/workflows/apk.yml` einfügen und speichern.
5. Reiter **Actions** öffnen. Der Lauf **APK bauen** dauert etwa 3–5 Minuten und endet mit einem grünen Haken.
6. Am Handy im Browser bei GitHub anmelden, das Repository öffnen und rechts unter **Releases** auf **Endless Space – aktuelle APK** tippen. Dort `EndlessSpace.apk` herunterladen.

## Installieren

1. Die heruntergeladene `EndlessSpace.apk` antippen.
2. Android fragt nach der Erlaubnis **Unbekannte Apps installieren** für den Browser oder Dateimanager: erlauben.
3. Google Play Protect warnt eventuell, weil die App nicht aus dem Play Store kommt: **Trotzdem installieren**.

## Weg B: mit Android Studio

1. Android Studio installieren und diesen Ordner über **Open** öffnen.
2. Gradle-Synchronisierung abwarten (lädt beim ersten Mal einige Komponenten aus dem Internet).
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. Die APK liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`. Per USB-Kabel, Cloud oder Mail aufs Handy bringen und installieren.

## Bedienung in der App

- **Zurück-Taste:** schließt nacheinander Dialoge, Menü und Flugplan und kehrt zur Raumkarte zurück. Auf der Karte wechselt die App in den Hintergrund, das Spiel bleibt erhalten.
- **Speichern:** Das Spiel speichert automatisch im App-Speicher, genau wie im Browser.
- **Spielstand als Datei:** „Spielstand speichern“ öffnet den Android-Dateidialog, du wählst den Ablageort. „Spielstand laden“ öffnet die Dateiauswahl.
- **Vom PC übernehmen:** Im Browser den Spielstand als JSON speichern, die Datei aufs Handy kopieren und in der App laden.

## Spiel aktualisieren

1. Die neue `EndlessSpace.html` nach `app/src/main/assets/EndlessSpace.html` legen. Auf GitHub: Datei öffnen, **…  → Upload files** in diesem Ordner und die Datei ersetzen.
2. GitHub baut automatisch eine neue APK unter **Releases**.
3. Die neue APK einfach über die alte installieren. **Nicht vorher deinstallieren**, sonst sind die gespeicherten Spielstände der App weg (vorher sicherheitshalber als JSON speichern).

## Signaturschlüssel

`app/endlessspace.keystore` signiert jede APK gleich. Nur deshalb lässt sich eine neue Version über die alte installieren. Die Datei aufbewahren und das Repository privat lassen. Geht der Schlüssel verloren, muss die App für ein Update deinstalliert werden.

## Aufbau

- `app/src/main/assets/EndlessSpace.html` – das Spiel (Build aus dem Spielprojekt)
- `app/src/main/java/de/endlessspace/game/MainActivity.java` – Vollbild-WebView, Zurück-Taste, Dateidialoge
- `.github/workflows/apk.yml` – automatischer Build auf GitHub
- Android Gradle Plugin 8.7.3, Gradle 8.11.1, Java 17, minSdk 24, targetSdk 34
