package de.endlessspace.game;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Shows the self-contained game (assets/EndlessSpace.html) full screen.
 * Saves stay in the WebView's local storage; JSON save files are written and
 * read through the Android file dialog.
 */
public class MainActivity extends Activity {

    private static final String GAME_URL = "file:///android_asset/EndlessSpace.html";
    private static final int REQUEST_OPEN_SAVE = 41;
    private static final int REQUEST_CREATE_SAVE = 42;

    private WebView web;
    private ValueCallback<Uri[]> pendingOpen;
    private String pendingSaveText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(12, 23, 33));

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setTextZoom(100);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) {
                    return false;
                }
                // External links open in the regular browser.
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                    // No app for this link.
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (pendingOpen != null) {
                    pendingOpen.onReceiveValue(null);
                }
                pendingOpen = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                // JSON files often have no proper MIME type on Android.
                intent.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "Spielstand laden"),
                            REQUEST_OPEN_SAVE);
                    return true;
                } catch (Exception e) {
                    pendingOpen = null;
                    showToast("Kein Dateimanager verfügbar.");
                    return false;
                }
            }
        });

        web.addJavascriptInterface(new AndroidBridge(), "EndlessSpaceAndroid");
        setContentView(web);
        web.loadUrl(GAME_URL);
    }

    /** Called from the game (window.EndlessSpaceAndroid). */
    public final class AndroidBridge {
        @JavascriptInterface
        public void saveFile(final String fileName, final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pendingSaveText = text;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, fileName);
                    try {
                        startActivityForResult(intent, REQUEST_CREATE_SAVE);
                    } catch (Exception e) {
                        pendingSaveText = null;
                        showToast("Kein Dateimanager verfügbar.");
                    }
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_OPEN_SAVE) {
            if (pendingOpen != null) {
                pendingOpen.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                pendingOpen = null;
            }
            return;
        }
        if (requestCode == REQUEST_CREATE_SAVE) {
            String text = pendingSaveText;
            pendingSaveText = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || text == null) {
                return;
            }
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out == null) {
                    throw new IOException("Kein Schreibzugriff");
                }
                out.write(text.getBytes(StandardCharsets.UTF_8));
                showToast("Spielstand gespeichert.");
            } catch (Exception e) {
                showToast("Speichern fehlgeschlagen: " + e.getMessage());
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /** Back closes dialogs and panels in the game first; at the map the app goes to the background. */
    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript(
                "(function(){try{return !!(window.ESMobile&&window.ESMobile.back());}catch(e){return false;}})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String handled) {
                        if (!"true".equals(handled)) {
                            moveTaskToBack(true);
                        }
                    }
                });
    }

    @Override
    protected void onPause() {
        // Lets the game save (it listens for the page becoming hidden).
        if (web != null) {
            web.evaluateJavascript("window.dispatchEvent(new Event('pagehide'))", null);
            web.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
